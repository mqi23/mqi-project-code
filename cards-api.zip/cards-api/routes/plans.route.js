const express = require("express");
const router = express.Router();
const plansController = require("../controllers/plans.controller");
router.get("/", plansController.getAllPlans),(req, res) => {
  const plans = plansController.getAllPlans();  
  res.json(plans);
};
router.get("/:id", plansController.getPlanById),(req, res) => {
  const planId = parseInt(req.params.id);
  const plan = plansController.getPlanById(planId);
  if (plan) {
      res.json(plan);
  } else {
      res.status(404).json({ message: "Plan not found" });
  }
};
router.get('/search', plansController.searchPlans),(req, res) => {
  const searchTerm = req.query.q ;
    if (!searchTerm) {
        return res.status(400).json({ message: 'Search term (q) is required.' });
    }
    const results = plansController.searchPlans(searchTerm);
    res.json(results);
};
module.exports = router;