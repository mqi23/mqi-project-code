const express = require('express');
const router = express.Router();
const stocksController = require('../controllers/stock.controller');
const authMiddleware = require('../middleware/auth'); 
router.get('/:planId/available', authMiddleware, stocksController.getAvailableStock),(req, res) => {
  const planId = parseInt(req.params.planId, 10);
  const availableItems = stocksController.getAvailableStock(planId);
  res.json(availableItems);
};
router.get('/:id', authMiddleware, stocksController.getStockItemById),(req, res) => {
  const itemId = parseInt(req.params.id, 10);
  const item = stocksController.getStockItemById(itemId);

  if (!item) {
      return res.status(404).json({ message: "Stock item not found" });
  }

  res.json(item);
};
router.get('/summary', stocksController.getStockSummary),(req, res) => {
  const summary = stocksController.getStockSummary();
  res.json(summary);
}; 
module.exports = router;