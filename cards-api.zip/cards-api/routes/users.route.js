const express = require("express");
const router = express.Router();
const userController = require("../controllers/users.controller");
const uthMiddleware = require("../middleware/auth");
const { plans } = require("../data");


router.post("/login", userController.loginUser,(req, res) => {
  let { phone, password } = req.body;
  let token = userController.login(phone, password);
  if (token) {
    res.json({ token });
  } else {
    res.status(401).json({ message: "Invalid phone or password" });
  }
}); 
router.get("/me",uthMiddleware, userController.getUsers),(req, res) => {
  const user = userController.getUsers(req.user.id);  
  if (user) {
    res.json(user);
  } else {
    res.status(404).json({ message: "User not found" });
  }
};  

router.post("/purchase", uthMiddleware, (req, res) => {
  const userId = req.user.id;
  const { planId } = req.body;  
  const plan = plans.find(p => p.id === planId);
  if (!plan) {
    return res.status(404).json({ message: "Plan not found" });
  } 
  const success = userController.purchasePlan(userId, plan);
  if (success) {
    res.json({ message: "Purchase successful", plan: plan });
  } else {
    res.status(400).json({ message: "Insufficient balance" });
  }   
});
module.exports = router;