const jwt = require('jsonwebtoken');
const { users } = require('../data'); 
const JWT_SECRET = process.env.JWT_SECRET || 'jbbihbhj k hbbh k jhb kjh 4321xyz';

const generateToken = (userProfile) => {

    return jwt.sign(
        { id: userProfile.id, name: userProfile.name, phone: userProfile.phone },
        JWT_SECRET,
        { expiresIn: '6h' } 
    );
}
const loginUser = (req, res) => {
    const { phone, password } = req.body;

    if (!phone || !password) {
        return res.status(401).json({ message: 'Phone and password are required.' });
    }
    const foundUser = users.find(u => u.phone === phone);
    if (!foundUser || foundUser.password !== password) {
        return res.status(401).json({ message: 'Invalid phone or password.' });
    }

    const token = generateToken(foundUser);

    res.json({ 
        message: 'Login successful',
        token: token 
    });
};
const getUsers = (req, res) => {
    const userProfile = users.find(u => u.id === req.user.id);
    
    if (!userProfile) {
        return res.status(404).json({ message: "User not found in data source." });
    }
    const { password, ...profile } = userProfile;
    res.json(profile);
};
const purchasePlan = (userId, plan) => {
    const user = users.find(u => u.id === userId);  
    if (user.balance >= plan.price) {
        user.balance -= plan.price;
        return true;
    }
    return false;
};
module.exports = {
    loginUser,
    getUsers, 
    purchasePlan
};