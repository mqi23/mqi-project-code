const plans = require("../db/plans.json")

const getAllPlans = (req, res) => {
    res.json(plans);
};
const getPlanById = (req, res) => {
    const planId = parseInt(req.params.id);
    const plan = plans.find(p => p.id === planId);
    if (plan) {
        res.json(plan);
    } else {
        res.status(404).json({ message: "Plan not found" });
    }
};  

const normalizeText = (text) => {
    return String(text).toLowerCase();
};
const searchPlans = (req, res) => {
    const searchTerm = req.query.q;

    if (!searchTerm) {
        return res.status(400).json({ message: 'Search term (q) is required.' });
    }
    const normalizedSearchTerm = normalizeText(searchTerm);
    const matchingPlans = plans.filter(plan => {
        const nameMatches = normalizeText(plan.name).includes(normalizedSearchTerm);
        const providerMatches = plan.provider && normalizeText(plan.provider).includes(normalizedSearchTerm);
        
        return nameMatches || providerMatches;
    });
    res.json({
        message: `Found ${matchingPlans.length} plans matching '${searchTerm}'`,
        results: matchingPlans
    });
};
module.exports = {
    getAllPlans,
    getPlanById,
    searchPlans
};