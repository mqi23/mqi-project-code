const { stock } = require('../db/stock.json');

const getAvailableStock = (code) => {
    if (!code || typeof code !== 'string' || code.length < 4) {
        return '****';
    }
    const stars = '*'.repeat(code.length - 4);
    return stars + code.slice(-4);
};
const getStockItemById = (req, res) => { 
    const itemId = parseInt(req.params.id, 10);
    const item = stock.find(m => m.id === itemId);

    if (!item) {
        return res.status(404).json({ message: "Stock item not found" });
    }
    const maskedItem = {
        id: item.id,
        planId: item.planId,
        status: item.status,
        code: maskCode(item.code)
    };

    res.json(maskedItem);
};
const getStockSummary = (req, res) => {

    const initialSummary = plans.reduce((acc, plan) => {
        acc[plan.id] = {
            planId: plan.id,
            ready: 0,
            sold: 0,
            error: 0,
            total: 0
        };
        return acc;
    }, {});
    const summaryMap = stock.reduce((acc, item) => {
        const pId = item.planId;
        if (!acc[pId]) {
             acc[pId] = { planId: pId, ready: 0, sold: 0, error: 0, total: 0 };
        }
        if (item.status === 'ready') {
            acc[pId].ready += 1;
        } else if (item.status === 'sold') {
            acc[pId].sold += 1;
        } else {
            acc[pId].error += 1;
        }
        acc[pId].total += 1;

        return acc;
    }, initialSummary);
    const finalSummary = Object.values(summaryMap);
    
    res.json({
        message: "Stock summary grouped by Plan ID",
        summary: finalSummary
    });
};

module.exports = {
    getStockItemById,
    getAvailableStock,
    getStockSummary
};