
const users = [
    {
    "id": 1,
    "name": "Admin",
    "phone": "07700000000",
    "password": "123456",
    "balance": 0
  },
  {
    "id": 2,
    "name": "Ali Hassan",
    "phone": "07710000000",
    "password": "1111",
    "balance": 25000
  },
  {
    "id": 3,
    "name": "Sara Ahmed",
    "phone": "07820000000",
    "password": "2222",
    "balance": 60000
  }
  
];
const plans = [    { id: 101, name: "Basic Monthly", price: 10000 },
    { id: 102, name: "Premium Quarterly", price: 25000 },
    { id: 103, name: "VIP Annual", price: 90000 }
  ];
const stocks = [
   {
    "id": 10001,
    "code": "ZAIN-010001-097",
    "planId": 101,
    "status": "ready"
  },
  {
    "id": 10002,
    "code": "ZAIN-010002-194",
    "planId": 101,
    "status": "ready"
  },
  {
    "id": 10003,
    "code": "ZAIN-010003-291",
    "planId": 101,
    "status": "ready"
  }
]; 


module.exports = {
    users,
    plans,
    stocks
};